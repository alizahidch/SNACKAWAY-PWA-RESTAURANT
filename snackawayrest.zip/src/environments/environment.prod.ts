export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyALyo1Ln_7IWbTtXvqp3rgNnXP23Cxi1FE",
    authDomain: "snackaway-app.firebaseapp.com",
    databaseURL: "https://snackaway-app.firebaseio.com",
    projectId: "snackaway-app",
    storageBucket: "snackaway-app.appspot.com",
    messagingSenderId: "621954494917",
    appId: "1:621954494917:web:811ffe3c50f6e739d2dbac",
    measurementId: "G-LVCD946YSJ"
  }
};
